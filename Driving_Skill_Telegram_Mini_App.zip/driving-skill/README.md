# Driving Skill — Telegram Mini App

A free starter 3D-style driving game built with Three.js and plain HTML/CSS/JavaScript.

## Files
- `index.html` — the complete game. No build step required.

## Test locally
Open `index.html` in a modern browser with an internet connection. Three.js is loaded from jsDelivr CDN.

## Free hosting with GitHub Pages
1. Sign in to https://github.com and create a new **public** repository named `driving-skill`.
2. Upload `index.html` to the repository root (the top level, not inside another folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish. Your game URL will look like:
   `https://YOUR-USERNAME.github.io/driving-skill/`
7. Open that URL in your phone browser and test it. Telegram Mini Apps require an HTTPS URL.

## Connect to Telegram
1. Open Telegram and chat with **@BotFather**.
2. Send `/mybots`, choose your bot, then **Bot Settings → Menu Button → Configure menu button** (the wording may vary).
3. Enter a button label such as `Play Game`.
4. Paste the HTTPS GitHub Pages URL from step 6.
5. Open your bot and tap its menu button. If your BotFather flow offers a Web App / Main App setting, you can configure the same URL there.

## Notes
- This starter stores coin best-score locally on the player's device (`localStorage`).
- It does not yet have a secure shared leaderboard, real-money rewards, user accounts, or server-side saving.
- Do not put bot tokens, passwords, or private keys in `index.html` or any public GitHub repository.
- GitHub Pages is free for public repositories, subject to GitHub's current usage terms.
- The game uses internet-loaded Three.js; it needs an internet connection to load the 3D engine.
